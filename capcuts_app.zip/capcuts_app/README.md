# 🧼 CapCuts — Video Sanitizer

Server lokal (Flask) buat "membersihkan" metadata dan fingerprint video hasil
export CapCut sebelum diupload ke TikTok/Instagram/dll — biar video lu gak
gampang ke-grouping/ke-flag sebagai "pakai template CapCut X" oleh sistem
deteksi konten platform.

Dijalankan 100% lokal di HP kamu lewat Termux, tanpa upload ke server luar.

## ✨ Fitur

- 🧹 Hapus semua metadata (author, device, GPS, chapters, dll) via `ffmpeg`
- 🔁 Re-encode ulang video (codec/bitrate/preset baru) → checksum berubah total
- 🔲 Micro-crop + rescale tipis (default 2%) → geometri frame sedikit beda
- ⏱️ Opsi ubah speed dikit (0.95x–1.05x) → durasi & pola frame beda
- 🎚️ Kontrol kualitas output (CRF) langsung dari UI
- 📤 Drag & drop upload + progress bar real-time
- 🌐 Auto-buka browser begitu server nyala
- ⌨️ Command `capcuts` di Termux buat langsung jalanin semuanya

## 📋 Requirements

- [Termux](https://f-droid.org/en/packages/com.termux/) (install dari F-Droid, bukan Play Store)
- Termux:API (buat auto-buka browser & notifikasi)
- Python 3.10+
- ffmpeg

## 🚀 Instalasi

```bash
# 1. Clone repo ini ke home folder Termux
git clone https://github.com/USERNAME/capcuts_app.git ~/capcuts_app
cd ~/capcuts_app

# 2. Jalankan installer (install ffmpeg, python deps, & setup alias)
bash install.sh

# 3. Reload shell config
source ~/.bashrc

# 4. Jalankan!
capcuts
```

Setelah `install.sh` selesai, cukup ketik **`capcuts`** di Termux kapan aja
buat langsung menjalankan server dan otomatis membuka browser ke halaman
upload di `http://127.0.0.1:8787`.

## 🖱️ Cara Pakai

1. Ketik `capcuts` di Termux
2. Browser otomatis kebuka ke halaman upload
3. Drag & drop (atau pilih) video hasil export CapCut
4. Atur opsi kalau perlu (crop %, speed, kualitas)
5. Tunggu progress bar sampai selesai
6. Klik **Download video bersih**

## 📁 Struktur Project

```
capcuts_app/
├── capcuts.sh          # launcher utama
├── install.sh           # setup otomatis Termux
├── server.py             # Flask backend + logic sanitasi (ffmpeg)
├── templates/
│   └── index.html        # halaman upload
├── static/
│   ├── style.css
│   └── app.js
├── uploads/               # file mentah sementara (auto-dihapus)
├── output/                # hasil video yang sudah bersih
├── requirements.txt
└── README.md
```

## ⚙️ Konfigurasi Manual

Semua opsi sanitasi bisa diatur langsung dari UI:

| Opsi         | Default | Keterangan                                  |
|--------------|---------|----------------------------------------------|
| Micro-crop   | ON      | Crop tipis lalu rescale ke ukuran semula      |
| Crop %       | 2%      | Seberapa besar crop yang dilakukan            |
| Speed        | 1.000x  | Ubah kecepatan video sedikit (0.95x–1.05x)    |
| CRF          | 23      | Kualitas encode (angka kecil = kualitas lebih tinggi, file lebih besar) |

## 🛑 Stop Server

Tekan `Ctrl+C` di Termux waktu server jalan.

## ⚠️ Disclaimer

Tool ini cuma memproses metadata & encoding video secara teknis (mirip proses
export ulang di aplikasi edit video pada umumnya). Kamu tetap bertanggung
jawab penuh atas konten yang kamu upload dan wajib mengikuti Ketentuan
Layanan platform yang kamu gunakan (TikTok, Instagram, dll).

## 📄 Lisensi

MIT — bebas dipakai, dimodif, dan disebarluaskan.
